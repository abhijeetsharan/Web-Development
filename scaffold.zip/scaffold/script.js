document.getElementById('location-form').addEventListener('submit', getWeather);

function getWeather(e) {
  //Write you code logic here

  // Error should be very specific
  // Error: Failed to fetch weather data,   should always fetch this error in case of any failure otherwise you test cases will get failed.
  

}